# install.ps1 - Installa la configurazione Claude Code nel workspace SIGAD
# Eseguire dalla directory contenente questo script

param(
    [string]$Workspace = "C:\Accredia\Sviluppo\AU",
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Info { param($msg) Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Success { param($msg) Write-Host "[OK] $msg" -ForegroundColor Green }
function Write-Warn { param($msg) Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err { param($msg) Write-Host "[ERROR] $msg" -ForegroundColor Red }

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  SIGAD Claude Code Installer" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Verifica workspace
if (-not (Test-Path $Workspace)) {
    Write-Info "Creazione workspace: $Workspace"
    New-Item -ItemType Directory -Path $Workspace -Force | Out-Null
}

# Files da copiare
$filesToCopy = @(
    "CLAUDE.md",
    ".gitignore",
    "sigad.pipeline.yaml"
)

$dirsToCopy = @(
    ".claude",
    "scripts"
)

# Copia files
foreach ($file in $filesToCopy) {
    $source = Join-Path $scriptDir $file
    $dest = Join-Path $Workspace $file
    
    if (Test-Path $source) {
        if ((Test-Path $dest) -and -not $Force) {
            Write-Warn "File esistente: $file (usa -Force per sovrascrivere)"
        } else {
            Copy-Item $source $dest -Force
            Write-Success "Copiato: $file"
        }
    }
}

# Copia directories
foreach ($dir in $dirsToCopy) {
    $source = Join-Path $scriptDir $dir
    $dest = Join-Path $Workspace $dir
    
    if (Test-Path $source) {
        if ((Test-Path $dest) -and -not $Force) {
            Write-Warn "Directory esistente: $dir (usa -Force per sovrascrivere)"
        } else {
            Copy-Item $source $dest -Recurse -Force
            Write-Success "Copiato: $dir/"
        }
    }
}

Write-Host ""
Write-Success "Installazione completata!"
Write-Host ""
Write-Info "Prossimi passi:"
Write-Host "  1. cd $Workspace"
Write-Host "  2. claude"
Write-Host "  3. /sigad-bootstrap"
Write-Host ""
