# Bootstrap Solution SIGAD

Esegui il bootstrap della solution Accredia.SIGAD seguendo queste regole:

## REGOLE OPERATIVE
- Workspace: C:\Accredia\Sviluppo\AU
- PRE-CHECK obbligatorio con tabella stato
- Idempotenza: verifica e correggi, non duplicare
- POST-CHECK: dotnet clean/build + health check

## OBIETTIVO
Creare o completare la solution .NET 9 `Accredia.SIGAD` con:

### Progetti da creare/verificare
- Accredia.SIGAD.Web (Blazor Server + MudBlazor, porta 7000)
- Accredia.SIGAD.Gateway (YARP, porta 7100)
- Accredia.SIGAD.Identity.Api (porta 7001)
- Accredia.SIGAD.Tipologiche.Api (porta 7002)
- Accredia.SIGAD.Anagrafiche.Api (porta 7003)
- Accredia.SIGAD.Shared (classlib)

### Vincoli
- Progetti direttamente sotto AU (vietato src/, apps/)
- Un solo profilo HTTP DEV
- Ogni API espone GET /health → 200 { "status": "ok" }
- VIETATO /weatherforecast o demo
- Web: MudBlazor obbligatorio
- Gateway: YARP configurato per routing

## PRE-CHECK
Produci tabella:
| Progetto | Esiste | In SLN | Conforme | Azione |

## POST-CHECK
1. dotnet clean && dotnet build
2. Verifica /health su porte 7001, 7002, 7003
